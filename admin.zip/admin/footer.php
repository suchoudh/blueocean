<!-- Footer -->
<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <span>© Copyright <?php echo date('Y'); ?> News | Powered by <a href="#">BlueOceanTech</a></span>
            </div>
        </div>
    </div>
</div>
<!-- /Footer -->
</body>
</html>
